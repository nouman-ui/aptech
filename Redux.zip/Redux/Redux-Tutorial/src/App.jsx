import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { increment, decrement, multiply } from "./assets/Redux/componentSplice/componentsSplice";
import NavBar from "./assets/components/Navbar";

function App() {
  const count = useSelector((state) => state.counter.value);
  const dispatch = useDispatch();

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <NavBar count={count} />

      <h1>Counter: {count}</h1>

      <div style={{ display: "flex", justifyContent: "center", gap: "10px" }}>
        <button onClick={() => dispatch(increment())}>Increment</button>
        <button onClick={() => dispatch(decrement())}>Decrement</button>
        <button onClick={() => dispatch(multiply())}>Multiply ×2</button>
      </div>
    </div>
  );
}

export default App;
