import { configureStore } from "@reduxjs/toolkit";
import counterReducer from "./componentSplice/componentsSplice";

export const store = configureStore({
  reducer: {
    counter: counterReducer,
  },
});
