const NavBar = ({ count }) => {
  return (
    <div style={{ background: "#eee", padding: "10px" }}>
      <p>Navbar count: {count}</p>
    </div>
  );
};

export default NavBar;
